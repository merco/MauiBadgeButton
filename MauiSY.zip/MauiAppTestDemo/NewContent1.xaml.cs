using MauiSY.SimpleDialogs;

namespace MauiAppTestDemo;

public partial class NewContent1 : ContentView, IMessageHelper, MauiSY.IMauiSYManager


{
	public NewContent1()
	{
		InitializeComponent();
	}

	public event EventHandler Clicked;
    public event EventHandler ExitRequest;

    public void autoFocus()
	{
		
	}

    public Task<bool> canExit()
    {
       return Task.FromResult(true);
    }

    public void InitUI(object arg)
    {
    }

    public void OnClicked(object sender, bool isOK)
    {
        if (Clicked != null)
        {
            MessageHelperEventArgs rv = new MessageHelperEventArgs();


            System.Collections.ArrayList lOut = new System.Collections.ArrayList();

            if (isOK)
            {
                rv.ClickValue = IMessageHelper.CLICKOK;
                rv.ReturnValue = "";
            }
            else
            {
                rv.ClickValue = IMessageHelper.CLICKCANCEL;
                rv.ReturnValue = "";
            }
            this.Clicked(this, rv);
        }
    }

    private void Button_Clicked(object sender, EventArgs e)
    {
        OnClicked(this, true);
    }
}