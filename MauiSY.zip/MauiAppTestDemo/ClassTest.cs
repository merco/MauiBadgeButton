﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiAppTestDemo
{
    public class ClassTest
    {
        public string Nome { get; set; } = "";
        public int Eta { get; set; } = 0;

        public System.Collections.Generic.List<string> Interessi { get; set; } = new System.Collections.Generic.List<string>();
    }
}
