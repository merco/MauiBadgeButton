﻿using MauiSY.Core;
using MauiSY.SimpleControls;
using MauiSY.SimpleDialogs;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Controls.PlatformConfiguration;
using System.Reflection;
using System.Runtime.InteropServices;

namespace MauiSY
{
    public interface IMauiSYManager
    {
        event EventHandler ExitRequest;
        System.Threading.Tasks.Task<bool> canExit();
        void InitUI(object arg);
    }
    public class MauiSyEventArgs : EventArgs
    {
        public int ClickValue
        { get; set; }
        public object ReturnValue
        { get; set; }

        public Instance.TopBarButton btn;
    }
    public  class Instance


    {

        public enum TopBarButton
        {
            BACK=0,
            LANGUAGE = 1,
            USER = 2,
            MORE =3
        }


        private static bool _ShowLangButton = true;
        private static bool _ShowUserButton = true;
        private static bool _ShowMoreButton = true;
        private static bool _barInitialized = false;

        public static string CONTENT_NAME_ROOT = "0";

        public static  string CURRENT_CONTENT_NAME { get; set; } = "";
        public static ContentView CURRENT_CONTENT_PAGE { get; set; } = null;
        public static Assembly CALLING_ASSEMBLY { get; set; } = null;
        public static string CALLING_ASSEMBLY_NAME { get; set; } = "";

        public static Grid CALLING_TOP_BAR { get; set; } = null;

        public static Grid CALLING_MENU_GRID { get; set; } = null;

        public static Frame CALLING_MAIN_FRAME { get; set; } = null;
        public static Label CALLING_TOP_BAR_LABEL { get; set; } = null;

        public static  SimpleControls.BadgeButton CALLING_TOP_BAR_BUTTON { get; set; } = null;
        public static SimpleControls.BadgeButton CALLING_TOP_BAR_BACKBUTTON { get; set; } = null;

        public static SimpleControls.BadgeButton CALLING_TOP_BAR_USERBUTTON { get; set; } = null;
        public static SimpleControls.BadgeButton CALLING_TOP_BAR_LANGUAGEBUTTON { get; set; } = null;

        public static Microsoft.Maui.Controls.Shell CALLING_APP { get; set; } = null;
        public static Assembly LOCAL_ASSEMBLY { get; set; } = null;
        public static string LOCAL_ASSEMBLY_NAME { get; set; } = "";

        public static string LOCAL_ASSEMBLY_IMAGEPATH { get; set; } = "MauiSY.SimpleImages.";
        public static string CALLING_ASSEMBLY_IMAGEPATH { get; set; } = "";
        public static ContentPage MAIN_PAGE { get; set; } = null;


        public static Core.Translations TranslationManager { get; set; } = null;

        public static Core.Preferences GlobalPreferences { get; set; } = null;



        public static string TopBarText
        {
            get
            {
                return CALLING_TOP_BAR_LABEL.Text;
            }
            set
            {
                CALLING_TOP_BAR_LABEL.Text = value;
            }
        }
        
        private async static Task<BadgeButton> makeTopBarButton(string name, string img)
        {
       
            BadgeButton vo = new SimpleControls.BadgeButton();
            vo.StyleId = name;
            vo.Padding = new Thickness(0, 0, 0, 0); 
            vo.Margin   = new Thickness(0, 0, 0, 0);
            vo.ImageSize = 40;
            //vo.BadgeImageText = img;
           
            vo.HorizontalOptions = LayoutOptions.CenterAndExpand;
            vo.Clicked += CALLING_TOP_BAR_BUTTON_CLICK;
            vo.VerticalOptions = LayoutOptions.Center;

            await Task.Run(() => {
                vo.setImmagine(Core.uty.getImage(img));
            });

           
            return vo;
        }

        public async static void SetUpTopBar(bool ShowLangButton = true, bool ShowUserButton = true, bool ShowMoreButton = true)
        {
            if (_barInitialized) return;
            _barInitialized = true;
            _ShowLangButton = ShowLangButton;
            _ShowMoreButton = ShowMoreButton;
            _ShowUserButton = ShowUserButton;
            CALLING_TOP_BAR = (Grid)CALLING_APP.FindByName("ShellViewObject");
            CALLING_MENU_GRID = (Grid)MAIN_PAGE.FindByName("MauiSY_menuGrid");
            CALLING_MAIN_FRAME = (Frame)MAIN_PAGE.FindByName("MauiSY_mainStage");

            if (CALLING_TOP_BAR == null) return;
            CALLING_TOP_BAR.Margin = new Thickness(0, 0, 0, 0);
            CALLING_TOP_BAR.Padding = new Thickness(0);
            CALLING_TOP_BAR.ColumnSpacing = 0;
            CALLING_TOP_BAR.RowSpacing = 0;
            CALLING_TOP_BAR.SetDynamicResource(Grid.BackgroundColorProperty, "Tertiary");


            CALLING_TOP_BAR_LABEL = new Label();

            CALLING_TOP_BAR_LABEL.FontSize = Device.GetNamedSize(NamedSize.Subtitle, typeof(Label));
            CALLING_TOP_BAR_LABEL.FontAttributes = FontAttributes.Bold;
            CALLING_TOP_BAR_LABEL.SetDynamicResource(Label.TextColorProperty, "White");
            CALLING_TOP_BAR_LABEL.Text = "Pippo";
            CALLING_TOP_BAR_LABEL.Padding = new Thickness(8, 0, 0, 0);
            CALLING_TOP_BAR_LABEL.HorizontalOptions = LayoutOptions.CenterAndExpand;
            CALLING_TOP_BAR_LABEL.VerticalTextAlignment = TextAlignment.Center;





           
            CALLING_TOP_BAR_BACKBUTTON = await makeTopBarButton("CALLING_TOP_BAR_BACKBUTTON", "backbutton.png");
            CALLING_TOP_BAR_BACKBUTTON.IsVisible = false;

            CALLING_TOP_BAR_LANGUAGEBUTTON = await makeTopBarButton("CALLING_TOP_BAR_LANGUAGEBUTTON", "lan_" + Translations.CurrentLanguage + ".png");
            CALLING_TOP_BAR_LANGUAGEBUTTON.IsVisible = _ShowLangButton;

            CALLING_TOP_BAR_USERBUTTON =await makeTopBarButton("CALLING_TOP_BAR_USERBUTTON", "user.png");
            CALLING_TOP_BAR_USERBUTTON.IsVisible = _ShowUserButton;
            CALLING_TOP_BAR_BUTTON = await makeTopBarButton("CALLING_TOP_BAR_BUTTON", "more.png"); // new SimpleControls.BadgeButton();
            CALLING_TOP_BAR_BUTTON.IsVisible = _ShowMoreButton;


            int aa = CALLING_TOP_BAR.ColumnDefinitions.Count;


             CALLING_TOP_BAR.Add(CALLING_TOP_BAR_BACKBUTTON, 0, 0);
            CALLING_TOP_BAR.Add(CALLING_TOP_BAR_LABEL,1,0);
            CALLING_TOP_BAR.Add(CALLING_TOP_BAR_LANGUAGEBUTTON, 2, 0);
            CALLING_TOP_BAR.Add(CALLING_TOP_BAR_USERBUTTON, 3, 0);
            CALLING_TOP_BAR.Add(CALLING_TOP_BAR_BUTTON,4,0);

   

            SetContent(CONTENT_NAME_ROOT);
        }
        public static void SetContent(System.Type pageIn,string title,object ObjIn=null)
        {
            var ee = pageIn;
            CALLING_MENU_GRID.IsVisible = false;
            ContentView V=  (ContentView)Activator.CreateInstance(pageIn);
            IMauiSYManager mm = (IMauiSYManager)V;
   
            CURRENT_CONTENT_NAME = "";
            CALLING_MAIN_FRAME.IsVisible = true;
            CALLING_MAIN_FRAME.Content = V;
            mm.InitUI(ObjIn);

            CURRENT_CONTENT_PAGE = V;

            CALLING_TOP_BAR_BACKBUTTON.IsVisible = true;
            CALLING_TOP_BAR_BUTTON.IsVisible = false;
            CALLING_TOP_BAR_BUTTON.IsVisible = _ShowUserButton;
            CALLING_TOP_BAR_LANGUAGEBUTTON.IsVisible = false;
            CALLING_TOP_BAR_USERBUTTON.IsVisible = false;

            TopBarText = title;
        }
        public static void SetContent (string ContName, object ObjIn = null)
        {
            CURRENT_CONTENT_NAME = ContName;
            if (CURRENT_CONTENT_NAME== CONTENT_NAME_ROOT)
            {
                CALLING_MENU_GRID.IsVisible = true;
                CALLING_MAIN_FRAME.Content = null;
                CALLING_MAIN_FRAME.IsVisible = false;
                TopBarText = CALLING_ASSEMBLY_NAME;
               CURRENT_CONTENT_PAGE = null;
                CALLING_TOP_BAR_BACKBUTTON.IsVisible = false;
                CALLING_TOP_BAR_BUTTON.IsVisible = _ShowMoreButton;
                CALLING_TOP_BAR_LANGUAGEBUTTON.IsVisible = _ShowLangButton;
                CALLING_TOP_BAR_USERBUTTON.IsVisible = _ShowUserButton;
            }
        }

        private async static void BackButtonPressed()
        {
            if (CURRENT_CONTENT_PAGE == null) return;
            IMauiSYManager mm = (IMauiSYManager)CURRENT_CONTENT_PAGE;
            bool isPossible = await mm.canExit();
            if (isPossible) SetContent(CONTENT_NAME_ROOT);
        }


        private static async void CALLING_TOP_BAR_BUTTON_CLICK(object sender, EventArgs e)
        {
            MauiSyEventArgs rv = new MauiSyEventArgs();
            var btn = (BadgeButton)sender;


            if (btn.StyleId== "CALLING_TOP_BAR_LANGUAGEBUTTON")
            {


                var outv = await DialogHelper.ShowLanguageSelector();
                rv.btn = TopBarButton.LANGUAGE;
                if (!outv) return;
     
            }
            if (btn.StyleId == "CALLING_TOP_BAR_BUTTON") rv.btn = TopBarButton.MORE;
           
            if (btn.StyleId== "CALLING_TOP_BAR_USERBUTTON") rv.btn = TopBarButton.USER;
           
            if (btn.StyleId == "CALLING_TOP_BAR_BACKBUTTON")
            {
                rv.btn = TopBarButton.BACK;
                BackButtonPressed();
            }
            TopBarButtonClicked(sender, rv);

        }

        public static event EventHandler TopBarButtonClicked;


        public static void EnableTopBar (bool enabled)
        {
            Instance.CALLING_TOP_BAR_BACKBUTTON.isClickable = enabled;
            Instance.CALLING_TOP_BAR_BUTTON.isClickable = enabled;
            Instance.CALLING_TOP_BAR_LANGUAGEBUTTON.isClickable = enabled;
        }

        public static void Init (Assembly assembly , ContentPage MainPage, string translationFile ="")
        {
            CALLING_ASSEMBLY=assembly;
            MAIN_PAGE = MainPage;
            var aA = Application.Current.Resources;
            SimpleDialogs.DialogManager.MainContentPage = MAIN_PAGE;
            CALLING_ASSEMBLY_NAME = CALLING_ASSEMBLY.FullName.Split(',')[0];

            LOCAL_ASSEMBLY = System.Reflection.Assembly.GetExecutingAssembly();
            LOCAL_ASSEMBLY_NAME = LOCAL_ASSEMBLY.FullName.Split(",")[0];

            LOCAL_ASSEMBLY_IMAGEPATH=LOCAL_ASSEMBLY_NAME+".SimpleImages.";
            CALLING_ASSEMBLY_IMAGEPATH = CALLING_ASSEMBLY_NAME + ".Images.";

            if (!string.IsNullOrEmpty(translationFile))
            {
                var tcontent = MauiSY.Core.uty.getTXT("traduzioni");
                if (!string.IsNullOrEmpty(tcontent)) TranslationManager = new Core.Translations(tcontent);

            }

            GlobalPreferences = new Core.Preferences();
            Core.Preferences.Load();
            Core.Preferences.Save();

            CALLING_APP =(Microsoft.Maui.Controls.Shell) Application.Current.MainPage;

     
  



        }



        private static void getPhotoWin()
        {








        }
        public static async void TakePhoto()
        {


            Media.PhotoService fs = new Media.PhotoService();



            var ss= await fs.GetPhoto();



     

         
        }
    }
}