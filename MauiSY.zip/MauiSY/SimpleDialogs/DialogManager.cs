﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;
using static System.Net.Mime.MediaTypeNames;

namespace MauiSY.SimpleDialogs
{
    public class MessageHelperEventArgs : EventArgs
    {
        public int ClickValue
        { get; set; }
        public object ReturnValue
        { get; set; }
    }
    public interface IMessageHelper
    {
        public const int CLICKOK = 1;
        public const int CLICKCANCEL = -1;
        event EventHandler Clicked;
        void autoFocus();
    }


    public class DialogHelper {

        public async static System.Threading.Tasks.Task<string>  InputBox (string textValue, string defaultValue ="")
        {

            var O = new DialogManager(new  SimpleControls.UIInputbox(textValue, defaultValue));
            O.Show();
            await O.WaitClose(0);

            if (O.clickvalue == IMessageHelper.CLICKCANCEL) return defaultValue;
            return O.returnValue.ToString();
        }

        public async static System.Threading.Tasks.Task<string> MsgboxInfo(string title, string text, int msAutoClose=0)
        {

            var O = new DialogManager(new SimpleControls.UiMessage(title,text,"OK","","",false));
            O.Show();
            await O.WaitClose(msAutoClose);
            return "";
        }
        public async static System.Threading.Tasks.Task<string> MsgboxErr(string title, string text, int msAutoClose = 0)
        {

            var O = new DialogManager(new SimpleControls.UiMessage(title, text, "OK", "", "", true));
            O.Show();
            await O.WaitClose(msAutoClose);
            return "";
        }
        public async static System.Threading.Tasks.Task<bool> MsgboxYesNo(string title, string text)
        {

            var O = new DialogManager(new SimpleControls.UiMessage(title, text, "OK", "Cancel", "", false));
            O.Show();
            await O.WaitClose(0);
            if (O.clickvalue == IMessageHelper.CLICKCANCEL) return false;
            return true;
        }
        public  static DialogManager WaitScreen()
        {

            var O = new DialogManager(new SimpleControls.UIWait());
            O.Show();
            
            return O;
        }
        public async static System.Threading.Tasks.Task<string> WaitScreenClose(DialogManager ws)
        {

            await ws.WaitClose(5);

            return "";
        }
        public async static System.Threading.Tasks.Task<string> Msgbox(string title, string message, string OK , string cancel,string img , int msAutoClose = 0)
        {

            var O = new DialogManager(new SimpleControls.UiMessage(title, message, OK, cancel, img, false));
            O.Show();
            await O.WaitClose(msAutoClose);
            return "";
        }
 

        public async static System.Threading.Tasks.Task<bool> ShowLanguageSelector()
        {
            var sl = new SimpleDialogs.UISelectLanguage();
            sl.setUp();
            var O = new DialogManager(sl);
            O.Show();
            await O.WaitClose(0);
            MessageHelperEventArgs le = new MessageHelperEventArgs();
            le.ReturnValue = O.returnValue;
            le.ClickValue = O.clickvalue;
            if (O.clickvalue == IMessageHelper.CLICKOK)
            {
           string v= ((Core.Translations.LanguageItem)le.ReturnValue).Value;
                MauiSY.Instance.TranslationManager.setCurrentLanguage(v);
                MauiSY.Instance.GlobalPreferences.UpdatePref("Language", v);
                MauiSY.Core.Preferences.Save();
                MauiSY.Instance.CALLING_TOP_BAR_LANGUAGEBUTTON.BadgeImageText = "lan_" + v + ".png";
                return true;
            }

            return false;
        }
    }

    public class DialogManager
    {

       
        public static ContentPage MainContentPage { get; set; }
        ContentPage _parent;
        View _child;

        ContentView _cvpopupView;

        EventHandler myClickEventhandler;
        public int clickvalue
        { get; set; }
        public object returnValue
        { get; set; }

        void HandleClick(object sender, EventArgs e)

        {
            MessageHelperEventArgs le = (MessageHelperEventArgs)e;
            returnValue = le.ReturnValue;
            clickvalue = le.ClickValue;
            _cvpopupView.IsVisible = false;

        }
        public DialogManager(View vw)
        {

            if (_parent == null) _parent = MainContentPage;
            _child = vw;
            myClickEventhandler = new EventHandler(HandleClick);
            _cvpopupView = (ContentView)_parent.FindByName("MauiSY_popupView");
            var i = (IMessageHelper)_child;
            i.Clicked += myClickEventhandler;
        }

        public async Task WaitClose(int msTimeOut)
        {
            int cnt = 0;
            while (clickvalue == 0)
            {
                await Task.Delay(250);
                cnt = cnt + 250;
                if (msTimeOut > 0 & cnt >= msTimeOut)
                {
                    MessageHelperEventArgs ee = new MessageHelperEventArgs();
                    ee.ReturnValue = null;
                    ee.ClickValue = 1;
                    HandleClick(null, ee);
                }
            }
            Instance.EnableTopBar(true);
        }
        public void Show()
        {
         

            Instance.EnableTopBar(false);
        
            _cvpopupView.Content = _child;
            _cvpopupView.IsVisible = true;
            var i = (IMessageHelper)_child;
            i.autoFocus();
        }
    }

    
}


