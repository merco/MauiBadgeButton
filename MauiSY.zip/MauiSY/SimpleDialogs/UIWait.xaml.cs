using MauiSY.SimpleDialogs;

namespace MauiSY.SimpleControls;

[XamlCompilation(XamlCompilationOptions.Compile)]
public partial class UIWait : ContentView, IMessageHelper
{
    public UIWait()
    {
        InitializeComponent();
    }

    public event EventHandler Clicked;

    public void autoFocus()
    {

    }
}