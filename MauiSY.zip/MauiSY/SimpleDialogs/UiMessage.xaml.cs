using MauiSY.SimpleDialogs;
using Microsoft.Win32.SafeHandles;

namespace MauiSY.SimpleControls;

[XamlCompilation(XamlCompilationOptions.Compile)]
public partial class UiMessage : ContentView, IMessageHelper
{
    public event EventHandler Clicked;
    public void OnClicked(object sender, int value)
    {
        if (Clicked != null)
        {
            // Call the custom event handler (assuming one has been set)
            //
            // You could always subclass EventArgs to send something more useful than
            // EventArgs.Empty here but more often than not that's not necessary
            MessageHelperEventArgs rv = new MessageHelperEventArgs();
            rv.ClickValue = value;

            rv.ReturnValue = null;

            this.Clicked(this, rv);
        }
    }
    public UiMessage()
    {
        InitializeComponent();
    }
    public UiMessage(String Title, String Message, String OK, String Cancel, String Img, bool isErr)
    {
        InitializeComponent();
        setData(Title, Message, OK, Cancel, Img, isErr);
    }


    public void setData(String Title, String Message, String OK, String Cancel, String Img, bool isErr)
    {
        txtTitle.Text = Title;
        txtText.Text = Message;

        if (isErr)
        {
            //txtTitle.BackgroundColor = Colors.Red;
            txtTitle.SetDynamicResource(Grid.BackgroundColorProperty, "Red300Accent");
            //theGrid.BackgroundColor = (Color)FindResource("FormLabelStyle"); // Color.FromRgb(255, 210, 210);
            theGrid.SetDynamicResource(Grid.BackgroundColorProperty, "Red100Accent");
        }

        if (!String.IsNullOrEmpty(OK))
        {
            //btnOK.Text = OK;
            btnOK.IsVisible = true;



        }
        else
        {
            btnOK.IsVisible = false;
        }
        if (!String.IsNullOrEmpty(Cancel))
        {
            //btnCancel.Text = Cancel;
            btnCancel.IsVisible = true;

        }
        else
        {
            btnCancel.IsVisible = false;
            Grid.SetColumnSpan(btnOK, 2);
        }

        if (!String.IsNullOrEmpty(Img))
        {


            var imageSource = Core.uty.getCallingImage(Img); //ImageSource.FromResource(Img, System.Reflection.Assembly.GetExecutingAssembly());
            theImage.Source = imageSource;
            theImage.IsVisible = true;
        }
        else
        {
            theImage.IsVisible = false;
            //txtText.row
            Grid.SetColumnSpan(txtText, 2);

        }
    }
    private void BtnOK_Clicked(object sender, EventArgs e)
    {
        OnClicked(sender, 1);
    }
    private void BtnCancel_Clicked(object sender, EventArgs e)
    {
        OnClicked(sender, -1);
    }

    public void autoFocus()
    {

    }
}