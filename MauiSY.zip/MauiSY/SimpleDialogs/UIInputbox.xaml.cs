using MauiSY.SimpleDialogs;

namespace MauiSY.SimpleControls;

[XamlCompilation(XamlCompilationOptions.Compile)]
public partial class UIInputbox : ContentView, IMessageHelper
{
    public UIInputbox(string textValue, string defaultValue)
    {
        InitializeComponent();
        lbl.Text = textValue;
        txtEdit.Text = defaultValue;
    }

    public event EventHandler Clicked;


    public void OnClicked(object sender, bool isOK)
    {
        if (Clicked != null)
        {
            MessageHelperEventArgs rv = new MessageHelperEventArgs();


            System.Collections.ArrayList lOut = new System.Collections.ArrayList();

            if (isOK)
            {
                rv.ClickValue = 1;
                rv.ReturnValue = txtEdit.Text;
            }
            else
            {
                rv.ClickValue = -1;
                rv.ReturnValue = "";
            }




            this.Clicked(this, rv);
        }
    }

    private void BagdeButtonBack_Clicked(object sender, EventArgs e)
    {
        OnClicked(sender, false);
    }

    private void BadgeButtonOK_Clicked(object sender, EventArgs e)
    {
        OnClicked(sender, true);
    }

    public void autoFocus()
    {
        txtEdit.Focus();
    }
}