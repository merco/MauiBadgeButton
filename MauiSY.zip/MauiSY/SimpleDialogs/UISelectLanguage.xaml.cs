using MauiSY.Core;
using MauiSY.SimpleControls;
using static MauiSY.Core.Translations;

namespace MauiSY.SimpleDialogs;

[XamlCompilation(XamlCompilationOptions.Compile)]
public partial class UISelectLanguage : ContentView, IMessageHelper
{
    public UISelectLanguage()
    {
        InitializeComponent();
    }

    System.Collections.Generic.List<LanguageItem> _list;


    public event EventHandler Clicked;

    public void autoFocus()
    {

    }
    public UILanguageItem Selected()
    {

        foreach (UILanguageItem li in sl.Children)
        {
            if (li.Selected) return li;
        }
        return null;
    }
    private void Tc_Clicked(object sender, EventArgs e)
    {
        SimpleControls.UILanguageItem c = (SimpleControls.UILanguageItem)sender;

        foreach (SimpleControls.UILanguageItem li in sl.Children)
        {
            li.Selected = false;
        }
        foreach (SimpleControls.UILanguageItem li in sl.Children)
        {
            if (c == li) li.Selected = true;
        }
        //OnClicked(null, true);
    }
    public void setUp()
    {

        _list = Translations.Languages.Values.ToList();


        var myDataTemplate = new DataTemplate(() =>
        {

            SimpleControls.UILanguageItem tc = new SimpleControls.UILanguageItem();
            tc.Selected = false;
            tc.SetBinding(SimpleControls.UILanguageItem.BasicListItemProperty, ".");
            MessageHelperEventArgs rv = new MessageHelperEventArgs();

            tc.Clicked += Tc_Clicked;

            return tc;
        });
        sl.ItemDataTemplate = myDataTemplate;
        sl.ItemsSource = _list;
    }
    public void OnClicked(object sender, bool isOK)
    {
        if (Clicked != null)
        {
            MessageHelperEventArgs rv = new MessageHelperEventArgs();


            rv.ReturnValue = null;

            if (isOK)
            {
                rv.ClickValue = 1;

                UILanguageItem LI = Selected();
                if (LI != null)
                {

                    rv.ReturnValue = LI.ListItem;
                }
                else return;



            }
            else rv.ClickValue = -1;




            this.Clicked(this, rv);
        }
    }
    private void BagdeButtonBack_Clicked(object sender, EventArgs e)
    {
        OnClicked(sender, false);
    }

    private void BadgeButtonOK_Clicked(object sender, EventArgs e)
    {
        OnClicked(sender, true);
    }

    private void UIPopUpTobBar_Clicked(object sender, SimpleControls.UIPopUpTobBar.UIPopUpBarResult e)
    {
        if (e == SimpleControls.UIPopUpTobBar.UIPopUpBarResult.OK) OnClicked(sender, true);
        else OnClicked(sender, false);
    }
}