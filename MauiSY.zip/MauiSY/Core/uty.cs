﻿
using System.Collections.ObjectModel;
using System.Text;

using Microsoft.Extensions.Logging;

namespace MauiSY.Core
{
    public class loggerDummy2 : ILogger
    {
        IDisposable ILogger.BeginScope<TState>(TState state)
        {
           return null;
        }

        bool ILogger.IsEnabled(LogLevel logLevel)
        {
            return false;
        }

        void ILogger.Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            
        }
    }

    public class loggerDummy : ILoggerFactory
    {
        void ILoggerFactory.AddProvider(ILoggerProvider provider)
        {
            
        }

        ILogger ILoggerFactory.CreateLogger(string categoryName)
        {
			return new loggerDummy2();
        }

        void IDisposable.Dispose()
        {
           
        }
    }

    public class uty
	{

		public static string NUMBER_FORMAT = "{0:0.##}";


		public double screenWidth
		{ get; set; }
		public double screenHeight
		{ get; set; }
		public double scalingFactor
		{ get; set; }
		public static bool isWPF
		{ get; set; }
		public uty()
		{
			
			
		}


        public static bool createFolder (string path)


        {
            try
			{
				if (!System.IO.Directory.Exists(path)) System.IO.Directory.CreateDirectory(path);

			}
			catch (Exception ex)
			{
				return false;
			}
			return true;
		}
		public static bool CopyFile(string from, string to)
		{
			try
			{
				 System.IO.File.Copy(from, to, true);
			}
			catch (Exception ex)
			{
				return false;
			}
			return true;
		}
		public static bool deleteFile(string path)
		{
			try
			{
				if (System.IO.File.Exists(path)) System.IO.File.Delete(path);
			}
			catch (Exception ex)
			{
				return false;
			}
			return true;
		}
	
        public static string Alphabetize(string s)
		{
			// 1.
			// Convert to char array.
			char[] a = s.ToCharArray();

			// 2.
			// Sort letters.
			Array.Sort(a);

			// 3.
			// Return modified string.
			return new string(a);
		}
		public static Collection<object>  dataTableToColl(System.Data.DataTable dd, int idxStart, int idxEnd ) {
			var outData = new Collection<object>();
			if (dd != null)
			{
				if (idxStart == -1) idxStart = 0;
				if (idxEnd == -1) idxEnd=dd.Rows.Count-1;
				if (idxEnd>= dd.Rows.Count) idxEnd = dd.Rows.Count - 1;
				if (idxStart >= dd.Rows.Count) idxStart = dd.Rows.Count - 1;

				for (int i = idxStart; i <= idxEnd; i++) outData.Add(dd.Rows[i]);
			}
			return outData;

		}
		public static String getDrValue (String Caption, String FieldName, System.Data.DataRow dr)
		{
			if (dr == null) return Caption;

			if (!dr.Table.Columns.Contains(FieldName)) return Caption;

			return Caption + NZ(dr[FieldName], "").ToString();
		}
		public static int Val(string s)
		{
			int retVal = 0;
			if (Int32.TryParse(s, out retVal))
			{

			}
			else
			{
				retVal = 0;
			}
			return retVal;
		}
		public static float ValF(string s)
		{
			float retVal = 0;
			if (float.TryParse(s, out retVal))
			{

			}
			else
			{
				retVal = 0;
			}
			return retVal;
		}
		private static MemoryStream GenerateStreamFromString(string value)
		{
			return new MemoryStream(Encoding.UTF8.GetBytes(value ?? ""));
		}

		public static string getTXT(String fileName)
		{
			System.IO.Stream tStream = Instance.CALLING_ASSEMBLY.GetManifestResourceStream(Instance.CALLING_ASSEMBLY_NAME + ".txt." + fileName + ".txt");
            string result = "";
			using (StreamReader reader = new StreamReader(tStream))
			{
			 result= reader.ReadToEnd();
			}
			tStream.Dispose();
			return result;
		}
        public static ImageSource getCallingImage(String filename)
		{
			return  ImageSource.FromResource(Instance.CALLING_ASSEMBLY_IMAGEPATH + filename, Instance.CALLING_ASSEMBLY);
        }

        public static  ImageSource getImage (String filename)
		{
	       return ImageSource.FromResource(Instance.LOCAL_ASSEMBLY_IMAGEPATH + filename, Instance.LOCAL_ASSEMBLY);

        }

		public static object NZ (object cosa,  object def)
		{
			if (System.Convert.IsDBNull(cosa))
			{
				return def;
			} else
			{
				return cosa;
			}
		}
		public static string NZ_str(object cosa)
		{
			return  (String) NZ(cosa, "");
		}
		public static int NZ_0(object cosa)
		{
            if (NZ(cosa, "").ToString()=="") return 0;
            return Convert.ToInt32(cosa);
		}
		public static bool IsNumeric(string value)
		{


			if (value=="-") return true;
			double numericValue;
			bool isNumber = double.TryParse(value, out numericValue);
			return isNumber;

		}
		public static long NZ_0L(object cosa)
		{
            if (NZ(cosa, "").ToString() == "") return 0;
            return Convert.ToInt64( NZ(cosa, 0));
		}
		public static decimal NZ_0_Dec(object cosa)
		{
            if (NZ(cosa, "").ToString() == "") return 0;
            Decimal appo = 0;
            try
            {
                appo = Convert.ToDecimal(NZ(cosa, 0), System.Globalization.CultureInfo.GetCultureInfo("it"));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return appo;
       
		}
		public static void activateEntry(Entry e)
		{
			e.Focus();

			if (!String.IsNullOrEmpty(e.Text))
			{
				e.CursorPosition = 0;
				e.SelectionLength = e.Text.Length;

			}

		}

		public static string SanitizeFileName (string fileName)
        {
			foreach (var c in System.IO.Path.GetInvalidFileNameChars())
			{
				fileName = fileName.Replace(c, '-');
			}
			fileName = fileName.Replace(' ', '_');
			return fileName;
		}
		//var value = double.Parse(Text.Replace(',', '.'), NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture);
		//https://stackoverflow.com/questions/51764129/xamarin-forms-entry-use-comma-as-decimal-separator
	
	public static string LocalPath()
		{
			var fs1 = FileSystem.Current.AppDataDirectory;
          var loc=  System.Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
			loc = System.IO.Path.Combine(loc, Instance.CALLING_ASSEMBLY_NAME);
			createFolder(loc);
			return loc;

        }
	
	}
}