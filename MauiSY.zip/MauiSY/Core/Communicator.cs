﻿using Microsoft.Maui.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiSY.Core
{
    public class AuthUser
    {
        public string UserName { get; set; } = "";
        public string Token { get; set; } = "";
    }
    public class Communicator
    {
        public static string DEFAULT_BASE_URL = "https://isparesSvilSidel.sygest.it/";
        string service_username = "sygest";
        string service_pwd = "sygest";
        public static string BASE_URL = "https://localhost";
        public AuthUser CurrentUser = null;

        public static bool PingAsync()
        {
            bool ok = false;
            NetworkAccess accessType = Connectivity.Current.NetworkAccess;
 
            if (accessType == NetworkAccess.Internet)
            {
                // Connection to internet is available
            }

            return ok;
        }
    }
}
