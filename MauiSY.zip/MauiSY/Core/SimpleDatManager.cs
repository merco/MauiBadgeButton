﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace MauiSY.Core
{
    public class SimpleDatManager

    //C:\Users\ewer\AppData\Local\Packages\A7BC0349-3D8D-4A12-9E79-B65BC495C95E_9zz4h110yvjzm\LocalCache\Local
    {
        public const string FileName = "Cache.DAT";

        public static  void Save(object o)
        {

     
            string fn = System.IO.Path.Combine(Core.uty.LocalPath(), FileName);
            if (System.IO.File.Exists(fn)) System.IO.File.Delete(fn);
            string serializedString = System.Text.Json.JsonSerializer.Serialize(o);
             System.IO.File.WriteAllText(fn, serializedString, System.Text.Encoding.Unicode);
        }
        public static T Load<T>()
        {


               string fn = System.IO.Path.Combine(Core.uty.LocalPath(), FileName);
            if (System.IO.File.Exists(fn))
            {
                string SFile = System.IO.File.ReadAllText(fn);

                try
                {
     
                    return System.Text.Json.JsonSerializer.Deserialize<T>(SFile);
                }
                catch (Exception ee)
                {
                    int a = 1;
                }
            }
            return default(T);
            


        }
    }
}
