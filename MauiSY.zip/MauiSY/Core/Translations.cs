﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiSY.Core
{
    public class Translations : IMarkupExtension<string>
    {

        public string TranslationValue { get; set; }
        public class LanguageItem
        {
            public string Value { get; set; }
            public string Image { get; set; }
            public override string ToString()
            {
                return Value;
            }
            public LanguageItem()
            {
                Value = "";
                Image = "lan_EN.png";
            }
        }
        public class TranslationItem
        {
            public string Value { get; set; }
            public string Language { get; set; }
            public override string ToString()
            {
                return Language;
            }
            public TranslationItem()
            {
                Value = "";
                Language = "";
            }
        }
        public class TranslationItems : System.Collections.Generic.Dictionary<string, TranslationItem>
        {

        }
        public static System.Collections.Generic.Dictionary<string, LanguageItem> Languages;
        public static System.Collections.Generic.Dictionary<string, TranslationItems> Items;
        public Translations()
        {
            TranslationValue = "";
        }

        public Translations(string DataTXT)
        {
            TranslationValue = "";
            Languages = new System.Collections.Generic.Dictionary<string, LanguageItem>();
            Items = new System.Collections.Generic.Dictionary<string, TranslationItems>();
            string[] rows = DataTXT.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            bool start = true;
            foreach (string row in rows)
            {
                string[] fld = row.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                if (start)
                {
                    foreach (string l in fld)
                    {
                        LanguageItem li = new LanguageItem();
                        li.Value = l.Replace("<BR>", "\r\n");
                        li.Image = "lan_" + l + ".png";
                        Languages.Add(l, li);
                    }

                    start = false;
                }
                else
                {
                    String K = "";
                    TranslationItems tis = new TranslationItems();
                    for (int i = 0; i < Languages.Count; i++)
                    {
                        TranslationItem ti = new TranslationItem();
                        ti.Language = Languages.ElementAt(i).Key;

                        ti.Value = fld[i];
                        ti.Value = ti.Value.Replace("<BR>", "\r\n");
                        if (ti.Language == "EN") K = ti.Value;
                        tis.Add(ti.Language, ti);

                    }
                    Items.Add(K.ToUpper(), tis);

                }
            }
        }
        public static string CurrentLanguage = "EN";
        public void setCurrentLanguage(string langCode)
        {
            if (Languages.ContainsKey(langCode)) CurrentLanguage = langCode;
        }
        public string Translate(string EnglishWords)
        {
            String vo = EnglishWords.ToUpper();
            if (Items == null) return EnglishWords;
            if (Items.ContainsKey(vo))
            {
                TranslationItems ti = Items[vo];
                if (ti.ContainsKey(CurrentLanguage)) vo = ti[CurrentLanguage].Value.Replace("§", "\r\n");
                else vo = vo + ".";
            }
            else vo = vo + ".";

            return vo;

        }
        public void FillPicker(Picker P)
        {
            P.Items.Clear();
            foreach (string V in Languages.Keys)
            {

                P.Items.Add(V);
            }
            P.SelectedItem = CurrentLanguage;
        }
        public string ProvideValue(IServiceProvider serviceProvider)
        {
            return Translate(TranslationValue);
        }

        object IMarkupExtension.ProvideValue(IServiceProvider serviceProvider)
        {
            return (this as IMarkupExtension<string>).ProvideValue(serviceProvider);
        }
    }
}
