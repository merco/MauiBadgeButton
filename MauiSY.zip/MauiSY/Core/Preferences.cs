﻿using System;
using System.Collections.Generic;
using System.IO.Enumeration;
using System.Text;

namespace MauiSY.Core
{
    public class PreferenceItem
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public override string ToString()
        {
            return Value;
        }
        public PreferenceItem()
        {
            Key = "";
            Value = "";
        }
    }
    public class Preferences : System.Collections.Generic.Dictionary <string, PreferenceItem>
    {

        //C:\Users\ewer\AppData\Local\Packages\A7BC0349-3D8D-4A12-9E79-B65BC495C95E_9zz4h110yvjzm\LocalCache\Local

        public const string FileName = "PREF.DAT";
        public static void Save()
        {

            StringBuilder sb = new StringBuilder();
            string fn = System.IO.Path.Combine(Core.uty.LocalPath(), FileName);
            if (System.IO.File.Exists(fn)) System.IO.File.Delete(fn);
            foreach (PreferenceItem pi in Instance.GlobalPreferences.Values)
            {
                sb.AppendLine(pi.Key + "=" + pi.Value);
            }
            System.IO.File.WriteAllText(fn, sb.ToString());


        }
        public static void Load()
        {
         

            PreferenceItem pi;

            pi = new PreferenceItem();
            pi.Key = "Language";
            pi.Value = "EN";
            String codL = System.Globalization.CultureInfo.CurrentUICulture.TwoLetterISOLanguageName.ToUpper();
            if (codL == "IT") pi.Value = "IT";
            Instance.GlobalPreferences.Add(pi.Key, pi);

            pi = new PreferenceItem();
            pi.Key = "URLHOST";
            pi.Value = "";
            Instance.GlobalPreferences.Add(pi.Key, pi);

            pi = new PreferenceItem();
            pi.Key = "UserId";
            pi.Value = "";
            Instance.GlobalPreferences.Add(pi.Key, pi);


            pi = new PreferenceItem();
            pi.Key = "Data";
            pi.Value = "";
            Instance.GlobalPreferences.Add(pi.Key, pi);


            if (Instance.GlobalPreferences.ContainsKey("Language")) Instance.TranslationManager.setCurrentLanguage(Instance.GlobalPreferences["Language"].Value);
            string fn = System.IO.Path.Combine(Core.uty.LocalPath(), FileName);
            if (!System.IO.File.Exists(fn)) return;
            string SFile = System.IO.File.ReadAllText(fn);
            if (string.IsNullOrEmpty(SFile)) return;
            string[] rows = SFile.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string row in rows)
            {

                string[] flds = row.Split(new char[] { '=' }, StringSplitOptions.RemoveEmptyEntries);
                if (Instance.GlobalPreferences.ContainsKey(flds[0]))
                {
                    if (flds.Length > 1)
                    {
                        Instance.GlobalPreferences.UpdatePref(flds[0], flds[1]);
                    }
                    else
                    {
                        Instance.GlobalPreferences.UpdatePref(flds[0], "");
                    }

                }
            }
            if (Instance.GlobalPreferences.ContainsKey("Language")) Instance.TranslationManager.setCurrentLanguage(Instance.GlobalPreferences["Language"].Value);


        }


        public string getAsString(string Key)
        {
            if (this.ContainsKey(Key)) return this[Key].Value;
            return "";
        }
        public int getAsInt(string Key)
        {
            if (this.ContainsKey(Key)) return Core.uty.NZ_0( this[Key].Value);
            return 0;
        }
        public void UpdatePref (string Key, String Value)
        {
            if (this.ContainsKey(Key))
            {
                PreferenceItem piNew = new PreferenceItem();

                this.Remove(Key);
                piNew.Key = Key;
                piNew.Value = Value;
                this.Add(piNew.Key, piNew);

            } 
        }
    }
}
