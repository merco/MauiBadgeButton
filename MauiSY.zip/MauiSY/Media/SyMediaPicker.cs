﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiSY.Media
{
    public partial class PhotoService
    {
        public partial  Task<byte[]> GetPhoto();
    }

}
