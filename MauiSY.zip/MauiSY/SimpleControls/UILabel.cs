﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiSY.SimpleControls
{
    public class UILabel : Label
    {
        public UILabel()
        {
            FontSize = Device.GetNamedSize(NamedSize.Small, typeof(Label));
            FontAttributes = FontAttributes.None;
            this.SetDynamicResource(Label.TextColorProperty, "Black");
        }
    }
}
