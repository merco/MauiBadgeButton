﻿using Microsoft.Maui.Graphics.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiSY.SimpleControls
{
    public class UIPopupLabel : Label
    {
        public UIPopupLabel()
        {
            FontSize = Device.GetNamedSize(NamedSize.Small, typeof(Label));
            FontAttributes = FontAttributes.Bold;

            VerticalOptions = LayoutOptions.FillAndExpand;
            HorizontalOptions = LayoutOptions.FillAndExpand;
            HorizontalTextAlignment = TextAlignment.Center;
            VerticalTextAlignment = TextAlignment.Center;
            this.SetDynamicResource(Label.TextColorProperty, "Black");

        }
    }
}
