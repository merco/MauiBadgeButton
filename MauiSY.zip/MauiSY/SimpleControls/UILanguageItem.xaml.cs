using static MauiSY.Core.Translations;

namespace MauiSY.SimpleControls;

[XamlCompilation(XamlCompilationOptions.Compile)]
public partial class UILanguageItem : ContentView
{

    private bool _selected = false;
    public static readonly BindableProperty BasicListItemProperty =
        BindableProperty.Create(nameof(LanguageItem), typeof(LanguageItem), typeof(UILanguageItem), null);

    public bool Selected
    {
        get { return _selected; }



        set
        {
            _selected = value;
            if (_selected) slc.SetDynamicResource(Grid.BackgroundColorProperty, "Red100Accent"); // slc.BackgroundColor = Colors.Pink;
            else slc.BackgroundColor = Colors.Transparent;
        }
    }
    public event EventHandler Clicked;
    public LanguageItem ListItem
    {
        get { return (LanguageItem)GetValue(BasicListItemProperty); }
        set { SetValue(BasicListItemProperty, value); }
    }
    public UILanguageItem()
    {
        InitializeComponent();
        GestureRecognizers.Add(new TapGestureRecognizer
        {
            Command = new Command(() =>
            {



                Clicked?.Invoke(this, new EventArgs());

            })
        });
    }

    private void BadgeButton_Clicked(object sender, EventArgs e)
    {
        Clicked?.Invoke(this, new EventArgs());
    }
}