﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiSY.SimpleControls
{
    public class BadgeButtonOK : BadgeButton
    {

        public BadgeButtonOK()
        {

            this.BadgeImageText = "fi-cwsuxm-check.png";
            this.ImageSize = 48;
        }
    }
}
