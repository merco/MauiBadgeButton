namespace MauiSY.SimpleControls;

[XamlCompilation(XamlCompilationOptions.Compile)]
public partial class UIPopUpTobBar : ContentView
{
    public enum UIPopUpBarResult
    {
        CANCEL,
        OK

    }


    public event EventHandler<UIPopUpBarResult> Clicked;


    public String Title
    {
        get
        {
            return mainLabel.Text;
        }


        set
        {
            mainLabel.Text = value;
        }
    }
    public UIPopUpTobBar()
    {
        InitializeComponent();
    }
    private void BagdeButtonBack_Clicked(object sender, EventArgs e)
    {
        //OnClicked(sender, false);

        Clicked?.Invoke(this, UIPopUpBarResult.CANCEL);


    }
    private void BadgeButtonOK_Clicked(object sender, EventArgs e)
    {


        Clicked?.Invoke(this, UIPopUpBarResult.OK);


    }
}