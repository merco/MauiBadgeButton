﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiSY.SimpleControls
{
    public class BagdeButtonBack : BadgeButton
    {
        public BagdeButtonBack()
        {
            this.BadgeImageText = "fi-cnsuxm-times-solid.png";
            this.ImageSize = 48;
        }
    }
}
