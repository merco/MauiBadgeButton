using System.ComponentModel;
using System.Windows.Input;

namespace MauiSY.SimpleControls;
[XamlCompilation(XamlCompilationOptions.Compile)]
public partial class BadgeButton : ContentView
{
    private bool _hideBadgeIfTextIsZero = true;
    private bool _isClickable = true;
    private Color _saveBadgeBackgroundColor = Colors.Transparent;
    public event EventHandler Clicked;

    public static readonly BindableProperty CommandProperty = BindableProperty.Create(nameof(Command), typeof(ICommand), typeof(BadgeButton));
    public static readonly BindableProperty CommandParameterProperty = BindableProperty.Create(nameof(CommandParameter), typeof(object), typeof(BadgeButton));


    public static readonly BindableProperty ImageSizeProperty = BindableProperty.Create(nameof(ImageSize), typeof(int), typeof(BadgeButton), 50);

    public static readonly BindableProperty ImageSourceProperty = BindableProperty.Create(nameof(ImageSource), typeof(ImageSource), typeof(BadgeButton), default(FileImageSource));
    public static readonly BindableProperty BadgeTextColorProperty = BindableProperty.Create(nameof(BadgeTextColor), typeof(Color), typeof(BadgeButton), Colors.White);
    public static readonly BindableProperty BadgeBackgroundColorProperty = BindableProperty.Create(nameof(BadgeBackgroundColor), typeof(Color), typeof(BadgeButton), Colors.Red);

    public static readonly BindableProperty BadgeImageTextProperty = BindableProperty.Create(nameof(BadgeImageText), typeof(string), typeof(BadgeButton), string.Empty);
    public static readonly BindableProperty BadgeTextProperty = BindableProperty.Create(nameof(BadgeText), typeof(string), typeof(BadgeButton), string.Empty);
    public static readonly BindableProperty BadgeFontSizeProperty = BindableProperty.Create(nameof(BadgeFontSize), typeof(double), typeof(BadgeButton), Device.GetNamedSize(NamedSize.Default, typeof(BadgeButton)));
    //public static readonly BindableProperty isClickableProperty = BindableProperty.Create(nameof(BadgeFontSize), typeof(double), typeof(BadgeButton), Device.GetNamedSize(NamedSize.Default, typeof(BadgeButton)));


    public ICommand Command
    {
        get { return (ICommand)GetValue(CommandProperty); }
        set { SetValue(CommandProperty, value); }
    }

    public object CommandParameter
    {
        get { return GetValue(CommandParameterProperty); }
        set { SetValue(CommandParameterProperty, value); }
    }

    public Color BadgeTextColor
    {
        get { return (Color)GetValue(BadgeTextColorProperty); }
        set { SetValue(BadgeTextColorProperty, value); }
    }

    public Color BadgeBackgroundColor
    {
        get { return (Color)GetValue(BadgeBackgroundColorProperty); }
        set { SetValue(BadgeBackgroundColorProperty, value); }
    }

    public ImageSource ImageSource
    {
        get { 
            
            return (ImageSource)GetValue(ImageSourceProperty); 
        
        
        
        }
        set { SetValue(ImageSourceProperty, value); }
    }

    public string BadgeText
    {
        get { return (string)GetValue(BadgeTextProperty); }
        set { SetValue(BadgeTextProperty, value); }
    }
    public int ImageSize
    {
        get { return (int)GetValue(ImageSizeProperty); }
        set { SetValue(ImageSizeProperty, value); }
    }
    public string BadgeImageText
    {
        get { return (string)GetValue(BadgeImageTextProperty); }
        set { SetValue(BadgeImageTextProperty, value); }
    }
    [TypeConverter(typeof(FontSizeConverter))]
    public double BadgeFontSize
    {
        get { return (double)GetValue(BadgeFontSizeProperty); }
        set { SetValue(BadgeFontSizeProperty, value); }
    }

    public bool HideBadgeIfTextIsZero
    {
        get
        {
            return _hideBadgeIfTextIsZero;
        }
        set
        {
            _hideBadgeIfTextIsZero = value;

            if (int.TryParse(BadgeText, out int parsedValue))
            {
                BadgeFrame.IsVisible = parsedValue != 0;
            }
            else
                BadgeFrame.IsVisible = true;
        }
    }
    public bool isClickable
    {
        get
        {
            return _isClickable;
        }
        set
        {
            _isClickable = value;

            if (_isClickable)
            {
                BadgeIconImage.Opacity = 1;
                if (_saveBadgeBackgroundColor != Colors.Transparent) BadgeBackgroundColor = _saveBadgeBackgroundColor;
            }
            else
            {
                //BadgeText = "";
                if (_saveBadgeBackgroundColor == Colors.Transparent) _saveBadgeBackgroundColor = BadgeBackgroundColor;

                BadgeIconImage.Opacity = 0.2;
                BadgeBackgroundColor = Colors.LightGray;
            }
        }
    }

    public void setImmagine(ImageSource ss)
    {
        BadgeIconImage.Source = ss;
    }
    public BadgeButton()
    {
        InitializeComponent();

        GestureRecognizers.Add(new TapGestureRecognizer
        {
            Command = new Command(() =>
            {
                Command?.Execute(CommandParameter);
                if (_isClickable)
                {
                    Clicked?.Invoke(this, new EventArgs());
                }
            })
        });



        _isReleased = true;
        _duration = Duration;


        _isClickable = true;
        BadgeFrame.BackgroundColor = BadgeBackgroundColor;
        BadgeTextLabel.Text = BadgeText;
        BadgeTextLabel.TextColor = BadgeTextColor;
        BadgeTextLabel.FontSize = BadgeFontSize;
        BadgeIconImage.Source = ImageSource;
        BadgeImageText = "";
    }

    protected override void OnPropertyChanged(string propertyName = null)
    {
        base.OnPropertyChanged(propertyName);

        if (BadgeFrame != null && propertyName == BadgeBackgroundColorProperty.PropertyName)
        {
            BadgeFrame.BackgroundColor = BadgeBackgroundColor;
        }

        if (BadgeTextLabel != null && propertyName == BadgeTextProperty.PropertyName)
        {
            BadgeTextLabel.Text = BadgeText;

            if (HideBadgeIfTextIsZero && int.TryParse(BadgeText, out int parsedValue))
            {
                BadgeFrame.IsVisible = parsedValue != 0;
            }
            else
                BadgeFrame.IsVisible = !string.IsNullOrEmpty(BadgeText);
        }

        if (BadgeTextLabel != null && propertyName == BadgeTextColorProperty.PropertyName)
        {
            BadgeTextLabel.TextColor = BadgeTextColor;
        }


        if (propertyName == ImageSizeProperty.PropertyName)
        {

            BadgeIconImage.WidthRequest = ImageSize;
            BadgeIconImage.HeightRequest = ImageSize;
        }

        if (BadgeImageText != null && propertyName == BadgeImageTextProperty.PropertyName)
        {

            var imageSource1 = Core.uty.getImage(BadgeImageText);      //ImageSource.FromResource(BadgeImageText, System.Reflection.Assembly.GetExecutingAssembly()); //ImageSource.FromStream(() => stream);


            //BadgeIconImage.Source = imageSource1;

        }

        if (BadgeTextLabel != null && propertyName == BadgeFontSizeProperty.PropertyName)
        {
            BadgeTextLabel.FontSize = BadgeFontSize;

            //if (BadgeFontSize <= 6)
            //{
            //    BadgeFrame.Padding = new Thickness(0, 2);
            //    BadgeFrame.CornerRadius = 2;
            //}

            //if (BadgeFontSize <= 8)
            //{
            //    BadgeFrame.Padding = new Thickness(0, 4);
            //    BadgeFrame.CornerRadius = 4;
            //}

            //if (BadgeFontSize <= 10)
            //{
            //    BadgeFrame.Padding = new Thickness(2, 6);
            //    BadgeFrame.CornerRadius = 10;
            //}

            //if (BadgeFontSize <= 12)
            //{
            //    BadgeFrame.Padding = new Thickness(8, 4);
            //}
        }

        if (BadgeIconImage != null && propertyName == ImageSourceProperty.PropertyName)
        {



            BadgeIconImage.Source = ImageSource;
        }
    }




    private readonly object _syncObject = new object();
    private const int Duration = 1000;

    //timer to track long press
    private Timer _timer;
    //the timeout value for long press
    private readonly int _duration;
    //whether the button was released after press
    private volatile bool _isReleased;

    /// <summary>
    /// Occurs when the associated button is long pressed.
    /// </summary>
    public event EventHandler LongPressed;





    public static readonly BindableProperty CommandPropertyLP = BindableProperty.Create(nameof(CommandLP), typeof(ICommand), typeof(BadgeButton));




    public static readonly BindableProperty CommandParameterPropertyLP = BindableProperty.Create(nameof(CommandParameterLP), typeof(object), typeof(BadgeButton));

    /// <summary>
    /// Gets or sets the command parameter.
    /// </summary>
    public object CommandParameterLP
    {
        get => GetValue(CommandParameterProperty);
        set => SetValue(CommandParameterProperty, value);
    }

    /// <summary>
    /// Gets or sets the command.
    /// </summary>
    public ICommand CommandLP
    {
        get => (ICommand)GetValue(CommandProperty);
        set => SetValue(CommandProperty, value);
    }

    //protected override void OnAttachedTo(Button button)
    //{
    //    base.OnAttachedTo(button);
    //    this.BindingContext = button.BindingContext;
    //    button.Pressed += Button_Pressed;
    //    button.Released += Button_Released;
    //}

    //protected override void OnDetachingFrom(Button button)
    //{
    //    base.OnDetachingFrom(button);
    //    this.BindingContext = null;
    //    button.Pressed -= Button_Pressed;
    //    button.Released -= Button_Released;
    //}

    /// <summary>
    /// DeInitializes and disposes the timer.
    /// </summary>
    private void DeInitializeTimer()
    {
        lock (_syncObject)
        {
            if (_timer == null)
            {
                return;
            }
            _timer.Change(Timeout.Infinite, Timeout.Infinite);
            _timer.Dispose();
            _timer = null;

        }
    }

    /// <summary>
    /// Initializes the timer.
    /// </summary>
    private void InitializeTimer()
    {
        lock (_syncObject)
        {
            _timer = new Timer(Timer_Elapsed, null, _duration, Timeout.Infinite);
        }
    }

    private void Button_Pressed(object sender, EventArgs e)
    {
        _isReleased = false;
        InitializeTimer();
    }

    private void Button_Released(object sender, EventArgs e)
    {
        _isReleased = true;
        DeInitializeTimer();
    }

    protected virtual void OnLongPressed()
    {
        var handler = LongPressed;
        handler?.Invoke(this, EventArgs.Empty);
        if (Command != null && Command.CanExecute(CommandParameter))
        {
            Command.Execute(CommandParameter);
        }
    }





    private void Timer_Elapsed(object state)
    {
        DeInitializeTimer();
        if (_isReleased)
        {
            return;
        }
        Device.BeginInvokeOnMainThread(OnLongPressed);
    }
}