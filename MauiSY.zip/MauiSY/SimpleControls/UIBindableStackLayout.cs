﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiSY.SimpleControls
{
    class UIBindableStackLayout : StackLayout
    {
        public IEnumerable ItemsSource
        {
            get { return (IEnumerable)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }
        public static readonly BindableProperty ItemsSourceProperty =
            BindableProperty.Create(nameof(ItemsSource), typeof(IEnumerable), typeof(UIBindableStackLayout),
                                    propertyChanged: (bindable, oldValue, newValue) => ((UIBindableStackLayout)bindable).PopulateItems());

        public DataTemplate ItemDataTemplate
        {
            get { return (DataTemplate)GetValue(ItemDataTemplateProperty); }
            set { SetValue(ItemDataTemplateProperty, value); }
        }
        public static readonly BindableProperty ItemDataTemplateProperty =
            BindableProperty.Create(nameof(ItemDataTemplate), typeof(DataTemplate), typeof(UIBindableStackLayout));

        void PopulateItems()
        {
            if (ItemsSource == null) return;
            foreach (var item in ItemsSource)
            {
                var itemTemplate = ItemDataTemplate.CreateContent() as View;
                itemTemplate.BindingContext = item;
                Children.Add(itemTemplate);
            }
        }
        private void Collection_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == NotifyCollectionChangedAction.Add)
            {
                foreach (var item in e.NewItems)
                {
                    var itemTemplate = ItemDataTemplate.CreateContent() as View;
                    itemTemplate.BindingContext = item;
                    Children.Add(itemTemplate);
                }
            }
            else if (e.Action == NotifyCollectionChangedAction.Remove)
            {
                if (Children.Count > 0)
                {
                    Children.RemoveAt(e.OldStartingIndex);
                }
            }
        }
        protected override void OnPropertyChanged(string propertyName = null)
        {
            base.OnPropertyChanged(propertyName);
            if (propertyName == UIBindableStackLayout.ItemsSourceProperty.PropertyName)
            {
                // When you change the ItemsSource property, set this event
                if (ItemsSource != null && ItemsSource is INotifyCollectionChanged collection)
                {
                    collection.CollectionChanged -= Collection_CollectionChanged;
                    collection.CollectionChanged += Collection_CollectionChanged;
                }
                if (ItemsSource != null)
                {
                    Children.Clear();
                    foreach (var item in ItemsSource)
                    {
                        var itemTemplate = ItemDataTemplate.CreateContent() as View;
                        itemTemplate.BindingContext = item;
                        //Children.Add(itemTemplate);
                    }
                }




            }
        }
    }
}
