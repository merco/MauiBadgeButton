namespace MauiSY.SimpleControls;

public class UIPopUpStack : StackLayout

{
    public UIPopUpStack()
    {

        this.SetDynamicResource(StackLayout.BackgroundColorProperty, "Primary");
        HorizontalOptions = LayoutOptions.CenterAndExpand;
        VerticalOptions = LayoutOptions.CenterAndExpand;
        Padding = new Thickness(2);
    }
}