﻿using System;

namespace MauiSY
{
    // All the code in this file is only included on Tizen.
    public class PlatformClass1
    {
    }
}