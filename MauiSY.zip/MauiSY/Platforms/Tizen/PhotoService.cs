﻿
namespace MauiSY.Media
{
    public partial class PhotoService
    {
        public partial void GetPhoto()
        {

        }
    }
}
