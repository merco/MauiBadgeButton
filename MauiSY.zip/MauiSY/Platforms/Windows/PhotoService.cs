﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Foundation.Collections;
using Windows.Media.Capture;
using Windows.Storage;
using Windows.System;
using WinRT.Interop;
namespace MauiSY.Media
{
    public partial class PhotoService
    {
        private readonly LauncherOptions _launcherOptions;

        public PhotoService()
        {
            var window = WindowStateManager.Default.GetActiveWindow();
            var handle = WindowNative.GetWindowHandle(window);

            _launcherOptions = new LauncherOptions();
            InitializeWithWindow.Initialize(_launcherOptions, handle);

            _launcherOptions.TreatAsUntrusted = false;
            _launcherOptions.DisplayApplicationPicker = false;
           
            _launcherOptions.TargetApplicationPackageFamilyName = "Microsoft.WindowsCamera_8wekyb3d8bbwe";
        }
        public partial async Task<byte[]> GetPhoto()
        {
            var extension = ".jpg";


            var currentAppData = ApplicationData.Current;
            var tempLocation = currentAppData.LocalCacheFolder;
            var tempFileName = $"capture{extension}";
            var tempFile = await tempLocation.CreateFileAsync(tempFileName, CreationCollisionOption.GenerateUniqueName);
            var token = Windows.ApplicationModel.DataTransfer.SharedStorageAccessManager.AddFile(tempFile);

            var set = new ValueSet();
            set.Add("MediaType", "photo");
            set.Add("PhotoFileToken", token);

            /*
            if (mode == CameraCaptureUIMode.Photo)
            {
                set.Add("MediaType", "photo");
                set.Add("PhotoFileToken", token);
            }
            else
            {
                set.Add("MediaType", "video");
                set.Add("VideoFileToken", token);
            }
            */
            var uri = new Uri("microsoft.windows.camera.picker:");
            var result = await Windows.System.Launcher.LaunchUriForResultsAsync(uri, _launcherOptions, set);
            if (result.Status == LaunchUriStatus.Success && result.Result != null)
            {
                byte[] vo = System.IO.File.ReadAllBytes(tempFile.Path);
                System.IO.File.Delete(tempFile.Path);
                return vo;
            }
            return null;
        }
    }
}