﻿
namespace MauiSY.Media
{
    public partial class PhotoService
    {
        public partial async Task<byte[]> GetPhoto()
        {
            return null;
        }
    }
}
