﻿
namespace MauiSY.Media
{
    public partial class PhotoService
    {

       

        private async void RequestCameraAccessAsync()
        {
            var status = await Permissions.CheckStatusAsync<Permissions.Camera>();

            if (status == PermissionStatus.Granted)
                return;

            if (status == PermissionStatus.Denied && DeviceInfo.Platform == DevicePlatform.iOS)
            {
                // Prompt the user to turn on in settings
                // On iOS once a permission has been denied it may not be requested again from the application
                return;
            }

            status = Permissions.RequestAsync<Permissions.Camera>().Result;
        }
        public partial async Task<byte[]> GetPhoto()
        {


            
            if (MediaPicker.Default.IsCaptureSupported)
            {
                FileResult photo = await MediaPicker.Default.CapturePhotoAsync();

                if (photo != null)
                {
                    // save the file into local storage
                    //string localFilePath = Path.Combine(FileSystem.CacheDirectory, photo.FileName);

                   // using Stream sourceStream = await photo.OpenReadAsync();
                   // using FileStream localFileStream = File.OpenWrite(localFilePath);

                   // await sourceStream.CopyToAsync(localFileStream);
                    byte[] outb=System.IO.File.ReadAllBytes(photo.FullPath);
                    System.IO.File.Delete(photo.FullPath);

                    return outb;
                }
            }


            return null;
        }
    }
}
